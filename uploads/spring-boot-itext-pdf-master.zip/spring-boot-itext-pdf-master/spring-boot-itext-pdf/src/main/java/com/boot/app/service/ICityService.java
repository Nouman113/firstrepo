package com.boot.app.service;

import java.util.List;

import com.boot.app.bean.City;

public interface ICityService {

	public List<City> findAll();
}
